import { getSupabaseAdmin } from './supabaseAdmin.ts';

export const logNotificationAttempt = async ({
  job_id,
  recipient_user_id,
  channel,
  message,
  status
}: {
  job_id: string;
  recipient_user_id?: string | null;
  channel: 'push' | 'whatsapp' | 'email';
  message: string;
  status: 'sent' | 'failed';
}) => {
  try {
    const supabase = getSupabaseAdmin();
    const { error } = await supabase.from('notifications').insert({
      job_id,
      recipient_user_id: recipient_user_id || null,
      channel,
      message,
      status,
      sent_at: new Date().toISOString()
    });
    if (error) {
      console.error('Failed to insert log into notifications table:', error);
    }
  } catch (error) {
    console.error('Failed to log notification:', error);
  }
};
