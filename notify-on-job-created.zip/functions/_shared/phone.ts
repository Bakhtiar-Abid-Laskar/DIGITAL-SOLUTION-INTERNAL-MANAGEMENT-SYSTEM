export const normalizePhoneForWhatsApp = (phone: string): string | null => {
  if (!phone) return null;
  // Remove non-digit chars except '+'
  const clean = phone.replace(/[^\d+]/g, '');
  
  if (clean.startsWith('+91') && clean.length === 13) {
    return `whatsapp:${clean}`;
  }
  if (clean.startsWith('91') && clean.length === 12) {
    return `whatsapp:+${clean}`;
  }
  if (clean.startsWith('0') && clean.length === 11) {
    return `whatsapp:+91${clean.substring(1)}`;
  }
  if (clean.length === 10) {
    return `whatsapp:+91${clean}`;
  }
  
  return null;
};
