export const sendExpoPushNotification = async (token: string, title: string, body: string, data: any = {}) => {
  try {
    const response = await fetch('https://exp.host/--/api/v2/push/send', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Accept-encoding': 'gzip, deflate',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        to: token,
        sound: 'default',
        title,
        body,
        data,
      }),
    });
    const result = await response.json();
    return { success: true, result };
  } catch (error: any) {
    console.error('Expo Push Error:', error);
    return { success: false, error: error.message };
  }
};
