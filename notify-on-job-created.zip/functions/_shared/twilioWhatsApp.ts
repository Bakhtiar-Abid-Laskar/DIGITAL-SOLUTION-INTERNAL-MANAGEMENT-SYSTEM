export const sendWhatsAppMessage = async (toPhone: string, message: string) => {
  const sid = Deno.env.get('TWILIO_SID');
  const token = Deno.env.get('TWILIO_TOKEN');
  const fromPhone = Deno.env.get('TWILIO_WHATSAPP_FROM');

  if (!sid || !token || !fromPhone) {
    return { success: false, error: 'Missing Twilio credentials' };
  }

  const url = `https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`;
  
  const body = new URLSearchParams({
    To: toPhone,
    From: fromPhone,
    Body: message,
  });

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': 'Basic ' + btoa(`${sid}:${token}`),
      },
      body: body.toString(),
    });
    
    const result = await response.json();
    
    if (!response.ok) {
      return { success: false, error: result.message || 'Twilio API Error' };
    }
    
    return { success: true, result };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
};
