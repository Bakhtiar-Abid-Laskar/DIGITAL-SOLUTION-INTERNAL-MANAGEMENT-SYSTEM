import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { getSupabaseAdmin } from "../_shared/supabaseAdmin.ts";
import { sendExpoPushNotification } from "../_shared/expoPush.ts";
import { sendWhatsAppMessage } from "../_shared/twilioWhatsApp.ts";
import { normalizePhoneForWhatsApp } from "../_shared/phone.ts";
import { logNotificationAttempt } from "../_shared/notificationLog.ts";

serve(async (req) => {
  try {
    const payload = await req.json();
    
    // Webhook payload from jobs table insert
    const record = payload.record;
    
    if (!record || !record.id || !record.job_code) {
      return new Response(JSON.stringify({ error: "Invalid payload" }), { status: 400 });
    }

    const supabase = getSupabaseAdmin();
    const results = [];

    // 1. Notify Technician
    if (record.technician_id) {
      const { data: tech } = await supabase
        .from('users')
        .select('expo_push_token')
        .eq('id', record.technician_id)
        .single();
        
      if (tech?.expo_push_token) {
        const title = "New Job Assigned";
        const body = `Job ${record.job_code} — ${record.device_type} — ${record.priority}`;
        
        const pushResult = await sendExpoPushNotification(tech.expo_push_token, title, body, {
          type: "job_created",
          job_id: record.id,
          job_code: record.job_code
        });

        await logNotificationAttempt({
          job_id: record.id,
          recipient_user_id: record.technician_id,
          channel: 'push',
          message: `${title}: ${body}`,
          status: pushResult.success ? 'sent' : 'failed'
        });
        
        results.push({ type: 'technician_push', success: pushResult.success });
      }
    }

    // 2. Notify Customer via WhatsApp
    if (record.customer_contact) {
      const waPhone = normalizePhoneForWhatsApp(record.customer_contact);
      const waMessage = `Hello ${record.customer_name}, your job has been registered with RepairShop. Your Job Code is ${record.job_code}. Please keep this code for future reference.`;
      
      if (waPhone) {
        const waResult = await sendWhatsAppMessage(waPhone, waMessage);
        
        await logNotificationAttempt({
          job_id: record.id,
          recipient_user_id: null,
          channel: 'whatsapp',
          message: waMessage,
          status: waResult.success ? 'sent' : 'failed'
        });
        
        results.push({ type: 'customer_whatsapp', success: waResult.success });
      } else {
        await logNotificationAttempt({
          job_id: record.id,
          recipient_user_id: null,
          channel: 'whatsapp',
          message: `Invalid phone format: ${record.customer_contact}`,
          status: 'failed'
        });
      }
    }

    return new Response(JSON.stringify({ success: true, results }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (error: any) {
    console.error(error);
    return new Response(JSON.stringify({ error: error.message }), { status: 500 });
  }
});
